const loginRoute = require('./loginRoute.js');
const registerRoute = require('./registerRoute.js');
const adminRoute = require('./adminRoute.js');
const userRoute = require('./userRoute.js');

module.exports = { loginRoute, registerRoute, adminRoute, userRoute };